import 'moment/locale/en-ie';
import * as FullCalendar from 'fullcalendar';


FullCalendar.locale("en-ie");
